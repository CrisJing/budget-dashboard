// jd-checkout.js: 购物车结算 → 提交订单 → 支付密码，一步到位
const CDP = require('chrome-remote-interface');
const fs = require('fs');
const CDP_PORT = 18800;
const PASSWORD = '152413';

async function run(targetId) {
  let client;
  try {
    client = await CDP({ port: CDP_PORT, target: targetId });
    const { Runtime, Page } = client;

    // Step 1: Check current URL
    const u = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
    const url = u.result.value;
    console.log('Current URL:', url);

    if (url.includes('cart')) {
      // Step 2: Click checkout button in cart
      const r = await Runtime.evaluate({ expression: `
        (() => {
          const els = document.querySelectorAll('a, button, div');
          for (const el of els) {
            const t = el.textContent.trim();
            if (t.includes('去结算') && t.length < 20) { el.click(); return 'clicked: ' + el.tagName + '.' + el.className.substring(0,60); }
          }
          return 'not found';
        })()
      `, returnByValue: true });
      console.log('Checkout click:', r.result.value);

      // Wait for order page to load
      await new Promise(r => setTimeout(r, 6000));

      const u2 = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
      console.log('After checkout URL:', u2.result.value);

      if (!u2.result.value.includes('getOrderInfo')) {
        console.log('❌ Did not navigate to order page');
        // Screenshot for debug
        const ss = await Page.captureScreenshot({ format: 'jpeg', quality: 60 });
        fs.writeFileSync('/tmp/jd_checkout_debug.jpg', Buffer.from(ss.data, 'base64'));
        console.log('Debug screenshot: /tmp/jd_checkout_debug.jpg');
        await client.close();
        return;
      }
    }

    // Step 3: Submit order
    if (true) {
      const u3 = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
      if (u3.result.value.includes('getOrderInfo') || u3.result.value.includes('trade.jd.com')) {
        console.log('On order page, submitting...');
        const sub = await Runtime.evaluate({ expression: `
          (() => {
            // Try direct selectors
            var btn = document.querySelector('.payment-action-submit button')
                   || document.querySelector('button.btn-primary.btn-large')
                   || document.querySelector('[class*=submit] button');
            if (btn) { btn.click(); return 'clicked submit button: ' + btn.textContent.trim(); }
            // Fallback: find by text
            var all = document.querySelectorAll('button, a, div');
            for (var i = 0; i < all.length; i++) {
              var t = all[i].textContent.trim();
              if (t.match(/^提交订单/) && t.length < 20) { all[i].click(); return 'clicked by text: ' + t; }
            }
            return 'submit button not found';
          })()
        `, returnByValue: true });
        console.log('Submit:', sub.result.value);

        // Wait for payment page
        await new Promise(r => setTimeout(r, 6000));

        const u4 = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
        console.log('After submit URL:', u4.result.value);

        // Screenshot
        const ss2 = await Page.captureScreenshot({ format: 'jpeg', quality: 60 });
        fs.writeFileSync('/tmp/jd_after_submit.jpg', Buffer.from(ss2.data, 'base64'));
        console.log('Screenshot: /tmp/jd_after_submit.jpg');

        // Check page text
        const txt = await Runtime.evaluate({ expression: 'document.body.innerText.substring(0, 500)', returnByValue: true });
        console.log('Page text:', txt.result.value);
      }
    }

  } catch (err) {
    console.error('❌ CDP error:', err.message);
  } finally {
    if (client) await client.close();
  }
}

const t = process.argv[2];
if (!t) { console.error('Usage: node jd-checkout.js <targetId>'); process.exit(1); }
run(t);
