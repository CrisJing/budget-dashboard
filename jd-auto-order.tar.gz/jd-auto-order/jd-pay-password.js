// jd-pay-password.js: nativeSetter + 单次 evaluate 完成密码填入和提交
//
// ===== 经验总结 =====
// 1. Vue/React 页面不要用 CDP 键盘输入（dispatchKeyEvent），视觉上有圆点但框架
//    v-model 不会捕获值。必须用 nativeSetter + dispatchEvent('input') 同步框架 state。
// 2. 多个同名按钮（如两个"立即支付"）用 getBoundingClientRect().top 排序，
//    取最小值选弹窗内的按钮，不要靠选择器顺序或 offsetWidth 过滤。
// 3. 尽量在一次 evaluate 中完成所有操作（取值 + 设值 + 点击），减少跨 evaluate 状态依赖。
//    安全页面的 evaluate 可能触发保护机制（清空输入），不能假设 evaluate 无副作用。
// 4. CDP dispatchKeyEvent 的"视觉欺骗"：DOM 显示了输入，但框架 state 可能为空。
// 5. 移动端页面可能只监听 touch 事件，桌面端可能只监听 mouse，混合页面建议都发。
// 6. 验证码有时效性，提交要快，过期需重新获取。
//
// ===== 技术方案 =====
// 1. 在一次 evaluate 中完成全部操作：
//    a. nativeSetter 设置密码值
//    b. dispatch input/change 事件同步 Vue state
//    c. 按 top 排序找到弹窗按钮（top 最小 = 弹窗层）
//    d. .click() 触发提交
// 2. 等待页面响应，截图确认结果
//
const CDP = require('chrome-remote-interface');
const CDP_PORT = 18800;
const PASSWORD = '152413';

async function run(targetId) {
  let client;
  try {
    client = await CDP({ port: CDP_PORT, target: targetId });
    const { Runtime, Page } = client;

    // 单次 evaluate：nativeSetter 填密码 + 点击弹窗按钮
    const result = await Runtime.evaluate({
      expression: `
        (function() {
          // 1) 找到密码框
          var input = document.querySelector('#shortPwdInput');
          if (!input) return JSON.stringify({ ok: false, reason: 'no #shortPwdInput' });

          // 2) nativeSetter 设值（绕过 Vue 劫持的 setter）
          var nativeSetter = Object.getOwnPropertyDescriptor(
            HTMLInputElement.prototype, 'value'
          ).set;
          input.focus();
          nativeSetter.call(input, '152413');
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));

          // 3) 找所有"立即支付"按钮，按 top 排序取弹窗内的
          var btns = document.querySelectorAll('.base-button.pointer-g');
          var candidates = [];
          for (var i = 0; i < btns.length; i++) {
            if (btns[i].textContent.trim() === '立即支付') {
              var rect = btns[i].getBoundingClientRect();
              candidates.push({
                el: btns[i],
                top: rect.top,
                x: Math.round(rect.left + rect.width / 2),
                y: Math.round(rect.top + rect.height / 2)
              });
            }
          }
          if (candidates.length === 0) return JSON.stringify({ ok: false, reason: 'no button' });
          candidates.sort(function(a, b) { return a.top - b.top; });
          var dialogBtn = candidates[0]; // top 最小 = 弹窗内

          // 4) 点击
          dialogBtn.el.click();

          return JSON.stringify({
            ok: true,
            pwd: input.value.length,
            btnCount: candidates.length,
            clicked: { x: dialogBtn.x, y: dialogBtn.y, top: Math.round(dialogBtn.top) }
          });
        })()
      `,
      returnByValue: true
    });

    const data = JSON.parse(result.result.value);
    if (!data.ok) {
      console.log('❌ 失败:', data.reason);
      process.exit(1);
    }
    console.log('✅ 密码已填入（' + data.pwd + '位），按钮已点击:', JSON.stringify(data.clicked));
    console.log('   共找到 ' + data.btnCount + ' 个"立即支付"按钮');

    // 等待页面响应
    await new Promise(r => setTimeout(r, 5000));

    // 截图确认结果
    const ss = await Page.captureScreenshot({ format: 'jpeg', quality: 60 });
    require('fs').writeFileSync('/tmp/jd_pay_result.jpg', Buffer.from(ss.data, 'base64'));
    console.log('📸 截图: /tmp/jd_pay_result.jpg');

    const urlR = await Runtime.evaluate({ expression: 'document.location.href' });
    console.log('URL:', urlR.result.value);
    const textR = await Runtime.evaluate({ expression: 'document.body.innerText.substring(0, 300)' });
    console.log('Text:', textR.result.value);

  } catch (err) {
    console.error('❌ CDP error:', err.message);
  } finally {
    if (client) await client.close();
  }
}

const t = process.argv[2];
if (!t) { console.error('Usage: node jd-pay-password.js <targetId>'); process.exit(1); }
run(t);
