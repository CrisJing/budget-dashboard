// jd-full-checkout.js: Navigate to cart → checkout → submit order → pay
const CDP = require('chrome-remote-interface');
const fs = require('fs');
const CDP_PORT = 18800;
const PASSWORD = '152413';

async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function run(targetId) {
  let client;
  try {
    client = await CDP({ port: CDP_PORT, target: targetId });
    const { Runtime, Page } = client;

    // Step 1: Navigate to cart
    console.log('Step 1: Navigating to cart...');
    await Page.navigate({ url: 'https://cart.jd.com/cart_index' });
    await sleep(5000);

    let u = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
    console.log('URL:', u.result.value);

    // Step 2: Click checkout button
    console.log('Step 2: Clicking checkout...');
    const r = await Runtime.evaluate({ expression: `
      (() => {
        var els = document.querySelectorAll('a, button, div, span');
        for (var i = 0; i < els.length; i++) {
          var t = els[i].textContent.trim();
          if (t.match(/去结算/) && t.length < 20) {
            els[i].click();
            return 'clicked: ' + els[i].tagName + '.' + els[i].className.substring(0,80) + ' text=' + t;
          }
        }
        // Also try common class selectors
        var btn = document.querySelector('.common-submit-btn')
               || document.querySelector('.submit-btn')
               || document.querySelector('[class*="submit"]');
        if (btn) { btn.click(); return 'clicked fallback: ' + btn.className; }
        return 'not found - body sample: ' + (document.body.innerText || '').substring(0, 300);
      })()
    `, returnByValue: true });
    console.log('Checkout:', r.result.value);

    await sleep(6000);

    u = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
    console.log('After checkout URL:', u.result.value);

    if (!u.result.value.includes('getOrderInfo') && !u.result.value.includes('trade.jd.com')) {
      console.log('❌ Not on order page, taking debug screenshot...');
      const ss = await Page.captureScreenshot({ format: 'jpeg', quality: 60 });
      fs.writeFileSync('/Users/mike/jd_debug.jpg', Buffer.from(ss.data, 'base64'));
      console.log('Debug screenshot: /Users/mike/jd_debug.jpg');
      
      // Check page text
      const txt = await Runtime.evaluate({ expression: 'document.body.innerText.substring(0, 500)', returnByValue: true });
      console.log('Page text:', txt.result.value);
      await client.close();
      return;
    }

    // Step 3: Submit order
    console.log('Step 3: Submitting order...');
    const sub = await Runtime.evaluate({ expression: `
      (() => {
        // Try various selectors
        var btn = document.querySelector('.payment-action-submit button')
               || document.querySelector('button.btn-primary.btn-large')
               || document.querySelector('[class*="submit"] button');
        if (btn) { btn.click(); return 'clicked: ' + btn.textContent.trim(); }
        // Fallback by text
        var all = document.querySelectorAll('button, a, div, span');
        for (var i = 0; i < all.length; i++) {
          var t = all[i].textContent.trim();
          if (t.match(/^提交订单/) && t.length < 20) { all[i].click(); return 'clicked text: ' + t; }
        }
        return 'submit not found - text: ' + (document.body.innerText || '').substring(0, 300);
      })()
    `, returnByValue: true });
    console.log('Submit:', sub.result.value);

    await sleep(6000);

    u = await Runtime.evaluate({ expression: 'location.href', returnByValue: true });
    console.log('After submit URL:', u.result.value);

    // Screenshot
    const ss2 = await Page.captureScreenshot({ format: 'jpeg', quality: 60 });
    fs.writeFileSync('/Users/mike/jd_after_submit.jpg', Buffer.from(ss2.data, 'base64'));
    console.log('Screenshot: /Users/mike/jd_after_submit.jpg');

    // Check page text
    const txt2 = await Runtime.evaluate({ expression: 'document.body.innerText.substring(0, 500)', returnByValue: true });
    console.log('Page text:', txt2.result.value);

  } catch (err) {
    console.error('❌ CDP error:', err.message);
  } finally {
    if (client) await client.close();
  }
}

const t = process.argv[2];
if (!t) { console.error('Usage: node jd-full-checkout.js <targetId>'); process.exit(1); }
run(t);
